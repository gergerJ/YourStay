package yourstay.md.util;

public class FileVO {
	private int file_num;
	private long aid;
	private String ipath;
    private String o_name;
    private String file_name;
    private long file_size;
    private int article_num;
}
