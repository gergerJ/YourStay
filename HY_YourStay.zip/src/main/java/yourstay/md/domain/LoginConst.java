package yourstay.md.domain;

public class LoginConst {
	public static final int YES_ID_PWD = 1; // 로그인성공
	public static final int EX_ID = 2; // 로그인 실패
}
