package yourstay.md.domain;

public class Image {
	private long iid;
	private String ipath1;
	private String ipath2;
	private String ipath3;
}
