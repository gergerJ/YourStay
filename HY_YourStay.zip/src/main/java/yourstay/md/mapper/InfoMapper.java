package yourstay.md.mapper;

import yourstay.md.domain.Accommodation;

public interface InfoMapper {
	
	Accommodation selectByaid(long aid);

}
